PIXEL INTERNET CAFE - WEB SITE

1. index.html dosyasini tek basina tarayicida acarak oyunu oynayabilirsin.
2. Internette yayinlamak icin bu klasordeki index.html dosyasini GitHub reposuna yukle.
3. GitHub reposunda Settings > Pages bolumune gir.
4. Deploy from a branch sec; branch olarak main ve folder olarak /(root) secip Save'e bas.
5. GitHub Pages site baglantisini olusturunca ayni sayfada gosterir.

Not: Google Fonts icin internet baglantisi gerekir. Oyun kaydi tarayicinin localStorage alaninda tutulur.
